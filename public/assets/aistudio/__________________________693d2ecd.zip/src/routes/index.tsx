import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Trash2, Plus, Minus, Download, Printer, Search, FileSpreadsheet, Image as ImageIcon, X,
  FolderOpen, FilePlus2, Copy, Upload, FileJson, ArrowUp, ArrowDown, Check, PenLine, FileText,
} from "lucide-react";
import { toast } from "sonner";
import { exportEstimate } from "@/lib/export-estimate";
import { computeTotals, fmt, sectionOf, SECTION_LABELS, tafqeet, type Section } from "@/lib/estimate-utils";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "منصة إعداد المقايسات - قائمة أسعار الهيئة العامة للأبنية 2023" },
      {
        name: "description",
        content:
          "منصة لإعداد المقايسات بالبحث في قائمة أسعار الهيئة العامة للأبنية التعليمية 2023 بالكود أو منطوق البند وإضافة الكميات وتصدير المقايسة.",
      },
      { property: "og:title", content: "منصة إعداد المقايسات - GEA 2023" },
      { property: "og:description", content: "ابحث بالكود أو منطوق البند، أضف الكميات، وصدّر المقايسة Excel و PDF." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Index,
});

type Item = { id: number; code: string; desc: string; unit: string; rate: number; part: string; page: number; section?: Section };
type LineItem = Item & { qty: number; section?: Section; custom?: boolean };

type Project = {
  id: string;
  updatedAt: number;
  projectName: string;
  clientName: string;
  orgName: string;
  governorate: string;
  refNumber: string;
  discountPercent: number;
  logoDataUrl: string;
  estimate: LineItem[];
};

const STORE_KEY = "gea_projects_v2";
const OLD_KEY = "gea_estimate_v1";

function newProject(partial: Partial<Project> = {}): Project {
  return {
    id: `p${Date.now()}${Math.floor(Math.random() * 1000)}`,
    updatedAt: Date.now(),
    projectName: "", clientName: "", orgName: "", governorate: "", refNumber: "",
    discountPercent: 0, logoDataUrl: "", estimate: [],
    ...partial,
  };
}

function normalize(s: string) {
  return s
    .replace(/[إأآا]/g, "ا").replace(/ى/g, "ي").replace(/ة/g, "ه")
    .replace(/[\u064B-\u0652\u0640]/g, "").replace(/\s+/g, " ").toLowerCase().trim();
}

type Filter = "all" | Section;

function Index() {
  const [items, setItems] = useState<Item[] | null>(null);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<Filter>("all");
  const [projects, setProjects] = useState<Project[]>([]);
  const [activeId, setActiveId] = useState<string>("");
  const [loaded, setLoaded] = useState(false);
  const [mounted, setMounted] = useState(false);
  const [showProjects, setShowProjects] = useState(false);
  const [showCustom, setShowCustom] = useState(false);
  const logoInputRef = useRef<HTMLInputElement>(null);
  const importRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setMounted(true);
    fetch("/data/items.json").then((r) => r.json()).then((d: Item[]) => setItems(d))
      .catch(() => toast.error("فشل تحميل قاعدة البيانات"));
    let list: Project[] = [];
    let active = "";
    try {
      const raw = localStorage.getItem(STORE_KEY);
      if (raw) {
        const s = JSON.parse(raw);
        list = s.projects || [];
        active = s.activeId || "";
      } else {
        const old = localStorage.getItem(OLD_KEY);
        if (old) list = [newProject(JSON.parse(old))];
      }
    } catch { /* ignore */ }
    if (!list.length) list = [newProject()];
    if (!list.find((p) => p.id === active)) active = list[0].id;
    setProjects(list);
    setActiveId(active);
    setLoaded(true);
  }, []);

  useEffect(() => {
    if (!loaded) return;
    try {
      localStorage.setItem(STORE_KEY, JSON.stringify({ projects, activeId }));
    } catch {
      toast.error("تعذّر الحفظ — مساحة التخزين ممتلئة (جرّب تصغير اللوجو)");
    }
  }, [projects, activeId, loaded]);

  const project = projects.find((p) => p.id === activeId) ?? newProject();
  const estimate = project.estimate;
  const update = (patch: Partial<Project> | ((p: Project) => Partial<Project>)) =>
    setProjects((list) =>
      list.map((p) => (p.id === activeId ? { ...p, ...(typeof patch === "function" ? patch(p) : patch), updatedAt: Date.now() } : p)),
    );
  const setEstimate = (fn: (e: LineItem[]) => LineItem[]) => update((p) => ({ estimate: fn(p.estimate) }));

  const qtyById = useMemo(() => new Map(estimate.map((x) => [x.id, x.qty])), [estimate]);

  const results = useMemo(() => {
    if (!items) return [];
    const pool = filter === "all" ? items : items.filter((it) => sectionOf(it.code, it.section) === filter);
    const q = normalize(query);
    if (!q) return pool.slice(0, 50);
    const normCode = (c: string) => c.replace(/[-\\/.]/g, "/").split("/").map((x) => x.replace(/^0+(?=\d)/, "")).join("/");
    const qc = /^[\d\s\-\/.]+$/.test(q) ? normCode(q.replace(/\s/g, "")) : q;
    const terms = q.split(" ").filter(Boolean);
    const scored: { it: Item; score: number }[] = [];
    for (const it of pool) {
      const code = normCode(it.code.toLowerCase());
      const desc = normalize(it.desc);
      let score = 0;
      if (code === qc) score += 100;
      else if (code.startsWith(qc)) score += 60;
      else if (code.includes(qc)) score += 40;
      if (terms.every((t) => desc.includes(t) || code.includes(t))) score += 10 + terms.length;
      if (score > 0) scored.push({ it, score });
      if (scored.length > 800) break;
    }
    scored.sort((a, b) => b.score - a.score);
    return scored.slice(0, 100).map((s) => s.it);
  }, [items, query, filter]);

  const addItem = (it: Item) => {
    if (qtyById.has(it.id)) {
      setEstimate((prev) => prev.map((p) => (p.id === it.id ? { ...p, qty: p.qty + 1 } : p)));
      toast.info("البند مضاف بالفعل — تمت زيادة الكمية");
    } else {
      setEstimate((prev) => [...prev, { ...it, qty: 1 }]);
      toast.success("تمت إضافة البند");
    }
  };
  const updateQty = (id: number, qty: number) => setEstimate((p) => p.map((x) => (x.id === id ? { ...x, qty: Math.max(0, qty) } : x)));
  const removeItem = (id: number) => setEstimate((p) => p.filter((x) => x.id !== id));
  const move = (idx: number, dir: -1 | 1) =>
    setEstimate((p) => {
      const j = idx + dir;
      if (j < 0 || j >= p.length) return p;
      const n = [...p];
      [n[idx], n[j]] = [n[j], n[idx]];
      return n;
    });
  const sortBySection = () =>
    setEstimate((p) => {
      const order: Section[] = ["ordinary", "sanitary", "electrical"];
      return [...p].sort((a, b) => order.indexOf(sectionOf(a.code, a.section)) - order.indexOf(sectionOf(b.code, b.section)));
    });
  const clearAll = () => { if (confirm("هل تريد مسح جميع بنود المقايسة؟")) setEstimate(() => []); };

  const totals = computeTotals(estimate, project.discountPercent);

  // ---- Projects ----
  const createProject = () => {
    const p = newProject({ orgName: project.orgName, logoDataUrl: project.logoDataUrl });
    setProjects((l) => [p, ...l]);
    setActiveId(p.id);
    setShowProjects(false);
    toast.success("تم إنشاء مقايسة جديدة");
  };
  const duplicateProject = (src: Project) => {
    const p = newProject({ ...src, id: undefined, projectName: `${src.projectName || "مقايسة"} (نسخة)` } as Partial<Project>);
    p.id = `p${Date.now()}`;
    setProjects((l) => [p, ...l]);
    setActiveId(p.id);
    toast.success("تم نسخ المقايسة");
  };
  const deleteProject = (id: string) => {
    if (!confirm("حذف هذه المقايسة نهائياً؟")) return;
    setProjects((l) => {
      const rest = l.filter((p) => p.id !== id);
      const final = rest.length ? rest : [newProject()];
      if (id === activeId) setActiveId(final[0].id);
      return final;
    });
  };
  const exportJson = () => {
    const blob = new Blob([JSON.stringify({ type: "gea-estimate", version: 2, project }, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `مقايسة-${project.projectName || "مشروع"}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };
  const importJson = (f: File | null) => {
    if (!f) return;
    f.text().then((txt) => {
      try {
        const d = JSON.parse(txt);
        const src = d.project ?? d;
        if (!Array.isArray(src.estimate)) throw new Error();
        const p = newProject({ ...src });
        p.id = `p${Date.now()}`;
        setProjects((l) => [p, ...l]);
        setActiveId(p.id);
        toast.success("تم استيراد المقايسة");
      } catch {
        toast.error("الملف غير صالح");
      }
    });
  };

  const onLogoPick = (f: File | null) => {
    if (!f) return;
    if (f.size > 1024 * 1024) return toast.error("حجم الصورة أكبر من 1MB");
    const reader = new FileReader();
    reader.onload = () => update({ logoDataUrl: String(reader.result || "") });
    reader.readAsDataURL(f);
  };

  const exportXlsx = async () => {
    if (!estimate.length) return toast.error("لا توجد بنود للتصدير");
    try {
      await exportEstimate(estimate, {
        orgName: project.orgName,
        projectTitle: project.projectName,
        governorate: project.governorate,
        refNumber: project.refNumber,
        discountPercent: project.discountPercent,
        logoDataUrl: project.logoDataUrl || undefined,
      });
      toast.success("تم تصدير المقايسة");
    } catch (e) {
      console.error(e);
      toast.error("فشل التصدير");
    }
  };

  const exportPdf = () => {
    if (!estimate.length) return toast.error("لا توجد بنود للتصدير");
    const prev = document.title;
    document.title = `مقايسة-${project.projectName || "مشروع"}`;
    toast.info("اختر «حفظ بتنسيق PDF» من نافذة الطباعة");
    setTimeout(() => {
      window.print();
      document.title = prev;
    }, 300);
  };

  const field = (label: string, key: keyof Project, placeholder: string) => (
    <div>
      <label className="text-xs font-semibold mb-1 block">{label}</label>
      <Input value={String(project[key] ?? "")} onChange={(e) => update({ [key]: e.target.value } as Partial<Project>)} placeholder={placeholder} />
    </div>
  );

  const sections: Section[] = ["ordinary", "sanitary", "electrical"];

  return (
    <div dir="rtl" className="min-h-screen bg-background text-foreground">
      <header className="border-b bg-card sticky top-0 z-20 print:hidden">
        <div className="max-w-7xl mx-auto px-4 py-3 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-primary text-primary-foreground grid place-items-center">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-lg font-bold leading-tight">منصة إعداد المقايسات</h1>
              <p className="text-xs text-muted-foreground">
                قائمة أسعار الهيئة العامة للأبنية التعليمية 2023 • {items?.length ?? "..."} بند
              </p>
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" onClick={() => setShowProjects((v) => !v)}>
              <FolderOpen className="w-4 h-4 ml-2" /> المقايسات ({projects.length})
            </Button>
            <Button variant="outline" onClick={() => window.print()}>
              <Printer className="w-4 h-4 ml-2" /> طباعة
            </Button>
            <Button variant="outline" onClick={exportPdf}>
              <FileText className="w-4 h-4 ml-2" /> PDF
            </Button>
            <Button onClick={exportXlsx}>
              <Download className="w-4 h-4 ml-2" /> Excel
            </Button>
          </div>
        </div>
      </header>

      {showProjects && (
        <div className="max-w-7xl mx-auto px-4 pt-4 print:hidden">
          <Card className="p-4">
            <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
              <h2 className="font-semibold">المقايسات المحفوظة</h2>
              <div className="flex flex-wrap gap-2">
                <Button size="sm" onClick={createProject}><FilePlus2 className="w-4 h-4 ml-1" /> مقايسة جديدة</Button>
                <Button size="sm" variant="outline" onClick={exportJson}><FileJson className="w-4 h-4 ml-1" /> حفظ نسخة (ملف)</Button>
                <input ref={importRef} type="file" accept="application/json,.json" className="hidden"
                  onChange={(e) => { importJson(e.target.files?.[0] || null); e.target.value = ""; }} />
                <Button size="sm" variant="outline" onClick={() => importRef.current?.click()}><Upload className="w-4 h-4 ml-1" /> فتح ملف</Button>
              </div>
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-2">
              {[...projects].sort((a, b) => b.updatedAt - a.updatedAt).map((p) => {
                const t = computeTotals(p.estimate, p.discountPercent);
                const active = p.id === activeId;
                return (
                  <div key={p.id} className={`border rounded-lg p-3 ${active ? "border-primary bg-primary/5" : ""}`}>
                    <button className="text-right w-full" onClick={() => { setActiveId(p.id); setShowProjects(false); }}>
                      <div className="font-semibold text-sm line-clamp-1">{p.projectName || "مقايسة بدون اسم"}</div>
                      <div className="text-xs text-muted-foreground mt-1">
                        {p.estimate.length} بند • {fmt(t.net)} ج.م
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {mounted ? new Date(p.updatedAt).toLocaleDateString("ar-EG") : ""}
                      </div>
                    </button>
                    <div className="flex gap-1 mt-2">
                      <Button size="sm" variant="ghost" className="h-7" onClick={() => duplicateProject(p)}><Copy className="w-3.5 h-3.5 ml-1" />نسخ</Button>
                      <Button size="sm" variant="ghost" className="h-7 text-destructive" onClick={() => deleteProject(p.id)}><Trash2 className="w-3.5 h-3.5 ml-1" />حذف</Button>
                    </div>
                  </div>
                );
              })}
            </div>
          </Card>
        </div>
      )}

      <main className="max-w-7xl mx-auto px-4 py-6 grid lg:grid-cols-5 gap-6 print:block print:p-0">
        {/* Search panel */}
        <section className="lg:col-span-2 space-y-4 print:hidden">
          <Card className="p-4">
            <label className="text-sm font-semibold mb-2 block">بحث عن بند</label>
            <div className="relative">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input value={query} onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Escape") setQuery("");
                  if (e.key === "Enter" && results[0]) addItem(results[0]);
                }}
                placeholder="أدخل كود البند أو جزء من منطوق البند" className="pr-10 h-11" />
            </div>
            <div className="flex flex-wrap gap-1.5 mt-3">
              {(["all", ...sections] as Filter[]).map((f) => (
                <Button key={f} size="sm" variant={filter === f ? "default" : "outline"} className="h-7 text-xs" onClick={() => setFilter(f)}>
                  {f === "all" ? "الكل" : SECTION_LABELS[f]}
                </Button>
              ))}
            </div>
            <div className="flex items-center justify-between mt-2">
              <p className="text-xs text-muted-foreground">
                {items ? `${results.length} نتيجة • Enter لإضافة أول نتيجة` : "جارٍ تحميل قاعدة البيانات..."}
              </p>
              <Button size="sm" variant="ghost" className="h-7 text-xs" onClick={() => setShowCustom((v) => !v)}>
                <PenLine className="w-3.5 h-3.5 ml-1" /> بند مستجد
              </Button>
            </div>
            {showCustom && <CustomItemForm onAdd={(li) => { setEstimate((p) => [...p, li]); setShowCustom(false); toast.success("تمت إضافة البند المستجد"); }} />}
          </Card>

          <div className="space-y-2 max-h-[calc(100vh-300px)] overflow-y-auto pl-1">
            {results.map((it) => {
              const q = qtyById.get(it.id);
              return (
                <Card key={it.id} className={`p-3 transition-colors ${q !== undefined ? "border-primary bg-primary/5" : "hover:border-primary"}`}>
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1 flex-wrap">
                        <span className="text-xs font-mono bg-secondary text-secondary-foreground px-2 py-0.5 rounded">{it.code}</span>
                        <span className="text-xs text-muted-foreground">{it.part} • ص {it.page}</span>
                        {q !== undefined && (
                          <span className="text-xs bg-primary text-primary-foreground px-2 py-0.5 rounded inline-flex items-center gap-1">
                            <Check className="w-3 h-3" /> مضاف
                          </span>
                        )}
                      </div>
                      <p className="text-sm leading-relaxed line-clamp-3">{it.desc}</p>
                      <div className="flex gap-4 mt-2 text-sm">
                        <span className="text-muted-foreground">الوحدة: <span className="text-foreground">{it.unit}</span></span>
                        <span className="font-semibold text-primary">{it.rate.toLocaleString("ar-EG")} ج.م</span>
                      </div>
                    </div>
                    {q !== undefined ? (
                      <div className="flex flex-col items-center gap-1">
                        <Button size="icon" className="h-7 w-7" onClick={() => updateQty(it.id, q + 1)}><Plus className="w-3.5 h-3.5" /></Button>
                        <Input type="number" value={q} onChange={(e) => updateQty(it.id, parseFloat(e.target.value) || 0)} className="h-7 w-16 text-center px-1" />
                        <Button size="icon" variant="outline" className="h-7 w-7" onClick={() => updateQty(it.id, q - 1)}><Minus className="w-3.5 h-3.5" /></Button>
                      </div>
                    ) : (
                      <Button size="sm" onClick={() => addItem(it)}><Plus className="w-4 h-4" /></Button>
                    )}
                  </div>
                </Card>
              );
            })}
            {items && !results.length && <p className="text-center text-muted-foreground py-8 text-sm">لا توجد نتائج مطابقة</p>}
          </div>
        </section>

        {/* Estimate panel */}
        <section className="lg:col-span-3 space-y-4">
          <Card className="p-4 print:hidden">
            <div className="grid sm:grid-cols-2 gap-3">
              {field("اسم الجهة (يظهر أعلى الغلاف)", "orgName", "مثال: مؤسسة / إدارة ...")}
              {field("اسم المشروع / عنوان المقايسة", "projectName", "مثال: المقايسة التقديرية لمدرسة ...")}
              {field("المحافظة / الموقع", "governorate", "مثال: مركز ... - محافظة ...")}
              {field("الجهة / العميل", "clientName", "مثال: مديرية التربية والتعليم")}
              {field("رقم التعريفى", "refNumber", "مثال: 2700290")}
              <div>
                <label className="text-xs font-semibold mb-1 block">نسبة الخصم (%)</label>
                <Input type="number" min={0} step="0.0001" value={project.discountPercent}
                  onChange={(e) => update({ discountPercent: parseFloat(e.target.value) || 0 })} />
              </div>
              <div className="sm:col-span-2">
                <label className="text-xs font-semibold mb-1 block">شعار الجهة (يظهر على الغلاف)</label>
                <div className="flex items-center gap-3">
                  <input ref={logoInputRef} type="file" accept="image/png,image/jpeg" className="hidden" onChange={(e) => onLogoPick(e.target.files?.[0] || null)} />
                  <Button type="button" variant="outline" size="sm" onClick={() => logoInputRef.current?.click()}>
                    <ImageIcon className="w-4 h-4 ml-2" /> اختر صورة اللوجو
                  </Button>
                  {project.logoDataUrl && (
                    <>
                      <img src={project.logoDataUrl} alt="logo" className="h-12 w-12 object-contain border rounded" />
                      <Button type="button" variant="ghost" size="sm" onClick={() => update({ logoDataUrl: "" })}>
                        <X className="w-4 h-4 ml-1" /> إزالة
                      </Button>
                    </>
                  )}
                </div>
              </div>
            </div>
          </Card>

          {/* Print cover */}
          <div className="hidden print:block print-cover">
            <div className="flex items-start gap-4 mb-4">
              {project.logoDataUrl && <img src={project.logoDataUrl} alt="" className="h-28 w-28 object-contain" />}
              <div className="flex-1 border border-foreground text-center">
                <div className="p-2 font-bold text-lg bg-[var(--print-green)]">{project.orgName || "—"}</div>
                <div className="p-3 font-bold text-xl bg-[var(--print-peach)] border-t border-foreground">{project.projectName || "مقايسة أعمال"}</div>
                {project.governorate && <div className="p-2 font-bold bg-[var(--print-peach)] border-t border-foreground">المحافظة: {project.governorate}</div>}
                {project.refNumber && <div className="p-2 font-bold border-t border-foreground">رقم تعريفى: {project.refNumber}</div>}
              </div>
            </div>
          </div>

          {/* Summary */}
          <Card className="p-4 print:shadow-none print:border-none print:p-0">
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 print:hidden">
              {sections.map((s) => (
                <div key={s} className="rounded-lg border p-3">
                  <div className="text-xs text-muted-foreground">{SECTION_LABELS[s]}</div>
                  <div className="font-bold mt-1">{fmt(totals[s])}</div>
                </div>
              ))}
              <div className="rounded-lg border p-3">
                <div className="text-xs text-muted-foreground">الإجمالي قبل الخصم</div>
                <div className="font-bold mt-1">{fmt(totals.grand)}</div>
              </div>
              <div className="rounded-lg border p-3">
                <div className="text-xs text-muted-foreground">الخصم ({project.discountPercent || 0}%)</div>
                <div className="font-bold mt-1 text-destructive">{fmt(totals.discount)}</div>
              </div>
              <div className="rounded-lg border-2 border-primary bg-primary/10 p-3">
                <div className="text-xs text-muted-foreground">الإجمالي العام</div>
                <div className="font-bold mt-1 text-primary">{fmt(totals.net)} ج.م</div>
              </div>
            </div>
            <table className="hidden print:table w-full text-sm border-collapse">
              <thead>
                <tr className="bg-[var(--print-gray)]">
                  <th className="border border-foreground p-2 w-16">مسلسل</th>
                  <th className="border border-foreground p-2">بيان الأعمال</th>
                  <th className="border border-foreground p-2 w-40">إجمالي البند</th>
                </tr>
              </thead>
              <tbody>
                {sections.map((s, i) => (
                  <tr key={s}>
                    <td className="border border-foreground p-2 text-center">{["أولاً", "ثانياً", "ثالثاً"][i]}</td>
                    <td className="border border-foreground p-2 text-center">إجمالي {SECTION_LABELS[s]}</td>
                    <td className="border border-foreground p-2 text-center font-bold">{fmt(totals[s])}</td>
                  </tr>
                ))}
                <tr className="bg-[var(--print-gray)] font-bold">
                  <td colSpan={2} className="border border-foreground p-2 text-center">الإجمالي</td>
                  <td className="border border-foreground p-2 text-center">{fmt(totals.grand)}</td>
                </tr>
                <tr>
                  <td colSpan={2} className="border border-foreground p-2 text-center">نسبة الخصم المقدمة من المقاول</td>
                  <td className="border border-foreground p-2 text-center">{project.discountPercent || 0}%</td>
                </tr>
                <tr>
                  <td colSpan={2} className="border border-foreground p-2 text-center">إجمالي قيمة الخصم</td>
                  <td className="border border-foreground p-2 text-center">{fmt(totals.discount)}</td>
                </tr>
                <tr className="font-bold">
                  <td colSpan={2} className="border border-foreground p-2 text-center bg-[var(--print-gray)]">الإجمالي العام</td>
                  <td className="border border-foreground p-2 text-center bg-[var(--print-yellow)]">{fmt(totals.net)}</td>
                </tr>
              </tbody>
            </table>
            <p className="mt-3 text-sm font-semibold leading-relaxed print:text-center print:border print:border-foreground print:p-2">
              {tafqeet(totals.net)}
            </p>
            <p className="hidden print:block text-xs mt-2">التاريخ: {mounted ? new Date().toLocaleDateString("ar-EG") : ""}</p>
          </Card>

          <Card className="overflow-hidden print:shadow-none print:border-none print:break-before-page">
            <div className="flex flex-wrap items-center justify-between gap-2 p-3 border-b bg-muted/40 print:hidden">
              <h2 className="font-semibold">بنود المقايسة ({estimate.length})</h2>
              {estimate.length > 0 && (
                <div className="flex gap-1">
                  <Button variant="ghost" size="sm" onClick={sortBySection}>ترتيب حسب القسم</Button>
                  <Button variant="ghost" size="sm" onClick={clearAll} className="text-destructive hover:text-destructive">
                    <Trash2 className="w-4 h-4 ml-1" /> مسح الكل
                  </Button>
                </div>
              )}
            </div>
            {estimate.length === 0 ? (
              <div className="p-12 text-center text-muted-foreground">
                <FileSpreadsheet className="w-12 h-12 mx-auto mb-3 opacity-40" />
                <p>لم تُضَف بنود بعد. ابدأ بالبحث ثم اضغط زر الإضافة.</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm print:border-collapse">
                  <thead className="bg-muted/60 text-xs print:bg-[var(--print-gray)]">
                    <tr>
                      <th className="p-2 text-right w-10 print:border print:border-foreground">م</th>
                      <th className="p-2 text-right w-24 print:border print:border-foreground">الكود</th>
                      <th className="p-2 text-right w-[316px] min-w-[316px] print:w-auto print:min-w-0 print:border print:border-foreground">البند</th>
                      <th className="p-2 text-right w-16 print:border print:border-foreground">الوحدة</th>
                      <th className="p-2 text-right w-32 print:border print:border-foreground">الكمية</th>
                      <th className="p-2 text-right w-24 print:border print:border-foreground">السعر</th>
                      <th className="p-2 text-right w-28 print:border print:border-foreground">الإجمالي</th>
                      <th className="p-2 w-20 print:hidden"></th>
                    </tr>
                  </thead>
                  <tbody>
                    {estimate.map((x, i) => (
                      <tr key={x.id} className="border-t align-top">
                        <td className="p-2 print:border print:border-foreground">{i + 1}</td>
                        <td className="p-2 font-mono text-xs print:border print:border-foreground">
                          {x.code}
                          {x.custom && <div className="text-[10px] text-muted-foreground font-sans">{SECTION_LABELS[sectionOf(x.code, x.section)]}</div>}
                        </td>
                        <td className="p-2 leading-relaxed w-[316px] min-w-[316px] print:w-auto print:min-w-0 print:border print:border-foreground">{x.desc}</td>
                        <td className="p-2 print:border print:border-foreground">{x.unit}</td>
                        <td className="p-2 print:border print:border-foreground">
                          <div className="flex items-center gap-1 print:hidden">
                            <Button size="icon" variant="outline" className="h-7 w-7" onClick={() => updateQty(x.id, x.qty - 1)}><Minus className="w-3 h-3" /></Button>
                            <Input type="number" min={0} step="0.01" value={x.qty}
                              onChange={(e) => updateQty(x.id, parseFloat(e.target.value) || 0)} className="h-7 w-16 px-1 text-center" />
                            <Button size="icon" variant="outline" className="h-7 w-7" onClick={() => updateQty(x.id, x.qty + 1)}><Plus className="w-3 h-3" /></Button>
                          </div>
                          <span className="hidden print:inline">{x.qty.toLocaleString("ar-EG")}</span>
                        </td>
                        <td className="p-2 print:border print:border-foreground">{x.rate.toLocaleString("ar-EG")}</td>
                        <td className="p-2 font-semibold print:border print:border-foreground">{fmt(x.qty * x.rate)}</td>
                        <td className="p-2 print:hidden">
                          <div className="flex items-center">
                            <div className="flex flex-col">
                              <button className="text-muted-foreground hover:text-foreground disabled:opacity-30" disabled={i === 0} onClick={() => move(i, -1)} aria-label="تحريك لأعلى"><ArrowUp className="w-3.5 h-3.5" /></button>
                              <button className="text-muted-foreground hover:text-foreground disabled:opacity-30" disabled={i === estimate.length - 1} onClick={() => move(i, 1)} aria-label="تحريك لأسفل"><ArrowDown className="w-3.5 h-3.5" /></button>
                            </div>
                            <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => removeItem(x.id)}><Trash2 className="w-4 h-4" /></Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot>
                    <tr className="border-t-2 bg-muted/40 font-bold">
                      <td colSpan={6} className="p-3 text-left print:border print:border-foreground">الإجمالي الكلي</td>
                      <td className="p-3 text-primary text-base print:border print:border-foreground">{fmt(totals.grand)} ج.م</td>
                      <td className="print:hidden"></td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            )}
          </Card>
        </section>
      </main>
    </div>
  );
}

function CustomItemForm({ onAdd }: { onAdd: (li: LineItem) => void }) {
  const [desc, setDesc] = useState("");
  const [unit, setUnit] = useState("");
  const [rate, setRate] = useState("");
  const [qty, setQty] = useState("1");
  const [section, setSection] = useState<Section>("ordinary");
  const submit = () => {
    const r = parseFloat(rate);
    if (!desc.trim() || !unit.trim() || !(r >= 0)) return toast.error("أدخل التوصيف والوحدة والسعر");
    onAdd({
      id: -Date.now(), code: "مستجد", desc: desc.trim(), unit: unit.trim(), rate: r,
      part: "", page: 0, qty: parseFloat(qty) || 1, section, custom: true,
    });
  };
  return (
    <div className="mt-3 border rounded-lg p-3 space-y-2 bg-muted/30">
      <textarea value={desc} onChange={(e) => setDesc(e.target.value)} placeholder="توصيف البند المستجد"
        className="w-full min-h-20 rounded-md border bg-background p-2 text-sm" />
      <div className="grid grid-cols-3 gap-2">
        <Input value={unit} onChange={(e) => setUnit(e.target.value)} placeholder="الوحدة" />
        <Input type="number" value={rate} onChange={(e) => setRate(e.target.value)} placeholder="السعر" />
        <Input type="number" value={qty} onChange={(e) => setQty(e.target.value)} placeholder="الكمية" />
      </div>
      <div className="flex gap-1.5 flex-wrap">
        {(["ordinary", "sanitary", "electrical"] as Section[]).map((s) => (
          <Button key={s} size="sm" type="button" variant={section === s ? "default" : "outline"} className="h-7 text-xs" onClick={() => setSection(s)}>
            {SECTION_LABELS[s]}
          </Button>
        ))}
      </div>
      <Button size="sm" className="w-full" onClick={submit}><Plus className="w-4 h-4 ml-1" /> إضافة للمقايسة</Button>
    </div>
  );
}
