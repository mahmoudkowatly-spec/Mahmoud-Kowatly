<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# النجم الهادي

يحصل المهندسون على مقايسات دقيقة ومسعّرة بالكامل لمشروعاتهم.

## المؤشر

المقايسات المُصدَّرة كل أسبوع
