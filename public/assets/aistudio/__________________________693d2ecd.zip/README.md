# منصة إعداد المقايسات — GEA BOQ Estimator

Single-page web app for preparing Bills of Quantities (BOQ / مقايسات) from the
General Educational Buildings Authority (GEA) price list (2026 edition, 5,622 items).
Users search by item code or description, add quantities, and export a styled
Excel workbook or print/save a PDF.

## Tech stack
- TanStack Start v1 (React 19, SSR) + TanStack Router (file-based routes in `src/routes`)
- Vite 8, TypeScript 5.8, Tailwind CSS v4 (configured in `src/styles.css`)
- shadcn/ui (Radix) components in `src/components/ui`, icons from `lucide-react`, toasts from `sonner`
- `exceljs` for the styled Excel export
- Vitest for unit tests
- Lovable Cloud (Supabase) client is wired but **no tables are used** — all user data lives in browser `localStorage`.

## Quick start
```bash
bun install          # or: npm install
cp .env.example .env # optional, only needed if you start using the backend
bun run dev          # http://localhost:8080 (port set by the Lovable Vite preset; Vite default is 5173)
bunx vitest run      # unit tests for totals, sections and tafqeet
bun run build        # production build (Cloudflare Workers target via nitro)
```

## Handover documents
| File | Content |
|---|---|
| `docs/handover/PROJECT_STRUCTURE.md` | Folder tree and role of each file, dependencies |
| `docs/handover/BUSINESS_LOGIC.md` | Exact formulas, classification, search, export rules |
| `docs/handover/FEATURES_DOCUMENTATION.md` | Every user-facing feature |
| `docs/handover/DATABASE_SCHEMA.md` | Backend status, data models (catalog + localStorage) |
| `docs/handover/DATABASE_MIGRATIONS/` | SQL migrations (none applied; optional future schema) |
| `docs/handover/MIGRATION_GUIDE.md` | Moving to Google AI Studio / independent hosting |
| `docs/handover/TESTING_CHECKLIST.md` | Manual + automated test procedures |
| `.env.example` | Environment variables (placeholders) |
